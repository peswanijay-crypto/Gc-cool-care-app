# GC Cool Care Android App (V1)

This is an offline-first Android Studio project for GC Cool Care.

## Included
- Customer details captured with each service booking
- AC brand/model, service type, appointment date, notes
- Job status: Pending / Completed / Cancelled
- Payment status: Pending / Paid / Credit
- Invoice preview with Android print / Save as PDF flow
- Offline storage using WebView localStorage
- JSON backup export and restore

## Build APK
1. Install Android Studio on a Windows/Mac/Linux computer.
2. Open this folder (`GC_Cool_Care_Android_Project`) in Android Studio.
3. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location (usually `app/build/outputs/apk/debug/app-debug.apk`).
6. Transfer that APK to your Android phone and install it. You may need to allow installation from that file manager.

## Important
- No internet permission or cloud service is used by this V1.
- Data is stored only on the device. Uninstalling or clearing app storage can erase it. Export backups regularly.
- Invoice print/save as PDF depends on Android's print service.
- WhatsApp sending is not yet automated; the invoice can be printed/saved as PDF and then shared manually.
- This source project has not been compiled or device-tested here. Build it in Android Studio before distributing.
